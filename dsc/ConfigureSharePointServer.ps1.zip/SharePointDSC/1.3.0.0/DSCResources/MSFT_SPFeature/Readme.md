**Description**

This resource is used to make sure that a specific feature is either enabled or disabled 
at a given URL/scope. The Ensure property will dictate if the feature should be on or 
off. The name property is the name of the feature based on its folder name in the 
FEATURES folder in the SharePoint hive directory. 
